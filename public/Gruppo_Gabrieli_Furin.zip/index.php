<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Ricerca Libro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
    <link rel="stylesheet" href="/assets/style/global.css">
    <style>

    </style>
</head>
<body>
    <?php include 'common/navbar.php'; ?>
    <div class="container">
        <h1>Benvenuto Bibliotecario/a</h1>
        <h4>Inizia ad usare il portale web per gestire i tuoi prestiti</h4>
    </div>
</body>
</html>
